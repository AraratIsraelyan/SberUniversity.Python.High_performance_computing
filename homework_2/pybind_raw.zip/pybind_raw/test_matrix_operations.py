import matrix
import numpy as np
import time

N = 2048 # 512, 1024, 4096 
A = np.random.rand(N, N).astype(np.float64)
B = np.random.rand(N, N).astype(np.float64)
C = np.zeros((N, N), dtype=np.float64)
x = np.random.rand(N).astype(np.float64)
y = np.zeros(N, dtype=np.float64)
print("C[0][0]", C[0,0])
start = time.perf_counter()
matrix.pybind11_matrix_multiply(A, B, C, N)
print("Matrix multiplication time:", time.perf_counter() - start)
print("C[0][0]", C[0,0])

