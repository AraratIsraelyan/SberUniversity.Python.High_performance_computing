#include "matrix_operations.h"

void matrix_multiply(double* A, double* B, double* C, int N) {
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            float sum = 0.0;
            for (int k = 0; k < N; k++)
            {
                sum = sum + (A[i*N+k] * B[k*N+j]);
            }
            C[i*N+j] = sum;
        }
    }
    return;
}
